document.addEventListener("DOMContentLoaded", function () {
    console.log("FARMM Webアプリ起動");
});
